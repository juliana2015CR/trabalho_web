package orkut.DAO;

import java.util.List;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import orkut.model.Album;
import orkut.model.Forum;
import orkut.model.Fotos;

@Repository
public class AlbumDAOHibernate implements IAlbumDAO{
	
	@PersistenceContext
	private EntityManager manager;
	
	@Override
	public void inserir(Album album) {
		manager.persist(album);
	}

	@Override
	public Album recuperar(Long alid) {
		return manager.find(Album.class, alid);
	}

	@Override
	public List<Album> listar() {
		String hql = "select f from ALBUM as f";

		return manager.createQuery(hql, Album.class).getResultList();
		
	}
	@Override
	public List<Fotos> listarF(Long alid) {
		String hql = "select a from FOTOS as a where alid = :var_id";
		Query query = manager.createQuery(hql);
		query.setParameter("var_id", alid);
		
		return query.getResultList();

	}

	@Override
	public Album recuperar(String nome) {
		String hql = "select f from ALBUM as f "
				+ "where u.nome =:var_nome";
		Query query = manager.createQuery(hql, Album.class);
		query.setParameter("var_nome", nome);
		List<Album> album = query.getResultList();

		if (album != null && !album.isEmpty()) {
			return album.get(0);
		}

		return null;
	}
	}
