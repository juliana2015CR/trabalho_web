package orkut.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;

import orkut.DAO.IComentariosDAO;
import orkut.model.Comentarios;


@Controller
@Transactional
public class ComentariosController {
	@Autowired
	@Qualifier(value="comentariosDAOHibernate")
	private IComentariosDAO comentariosDAO;
	
	@RequestMapping("/inserirComentarioFormulario")
	//links
	public String inserirComentariosFormulario(){
		return "comentarios/inserir_comentario_formulario";
	}
	@RequestMapping("/inserirComentario")
	public String inserirComentarios(Comentarios comentarios){
		comentariosDAO.inserir(comentarios);
		return "comentarios/inserir_ok";
	}
}
