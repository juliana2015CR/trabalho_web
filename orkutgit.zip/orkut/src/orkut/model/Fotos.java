package orkut.model;

import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity(name="FOTOS")

public class Fotos {
		@Id
		@Column(name="FOT_ID")
		@GeneratedValue(strategy=GenerationType.AUTO)
		private Long fotid;
		
		@Column(name="IMAGEM")
		private String imagem;
		
		@Column(name = "USU_ID", insertable=false, updatable = false, nullable=false)
		private Long usuId;
		
		@ManyToOne(optional = false)
		@JoinColumn(name = "USU_ID",
					referencedColumnName = "USU_ID")
		private Usuario usuario;
		
		@OneToMany(mappedBy="fotos", 
				targetEntity = Comentarios.class, 
				fetch = FetchType.EAGER)
		private Collection<Comentarios> comentarios;

		public Long getFotid() {
			return fotid;
		}

		public void setFotid(Long fotid) {
			this.fotid = fotid;
		}

		public String getImagem() {
			return imagem;
		}

		public void setImagem(String imagem) {
			this.imagem = imagem;
		}

		public Long getUsuId() {
			return usuId;
		}

		public void setUsuId(Long usuId) {
			this.usuId = usuId;
		}

		public Usuario getUsuario() {
			return usuario;
		}

		public void setUsuario(Usuario usuario) {
			this.usuario = usuario;
		}

		public Collection<Comentarios> getComentarios() {
			return comentarios;
		}

		public void setComentarios(Collection<Comentarios> comentarios) {
			this.comentarios = comentarios;
		}


}
