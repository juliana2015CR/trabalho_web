package orkut.controller;


import javax.servlet.ServletContext;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import orkut.DAO.IComunidadeDAO;
import orkut.model.Comunidade;
import orkut.util.AulaFileUtil;

@Controller
@Transactional
public class ComunidadeController {
	
	@Autowired
	@Qualifier(value="comunidadeDAOHibernate")
	private IComunidadeDAO comunidadeDAO;
	
	@Autowired
	private ServletContext context;
	
	@RequestMapping("/inserirComunidadeFormulario")
	//links
	public String inserirComunidadeFormulario(){
		return "comunidades/inserir_comunidade_formulario";
	}
	@RequestMapping("/inserirComunidade")
	public String inserirComunidade(Comunidade comunidade,
		@RequestParam(value="image",required=false)MultipartFile image){

			if(image!=null && !image.isEmpty()){
				String path = context.getRealPath("/");
				path+="resources/images/"+comunidade.getNome()+".png";
				AulaFileUtil.saveFile(path, image);
				
			}
				
		comunidadeDAO.inserir(comunidade);
		return "comunidades/inserir_ok";
	}
}

