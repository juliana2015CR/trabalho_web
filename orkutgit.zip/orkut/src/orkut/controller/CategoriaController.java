package orkut.controller;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


import orkut.model.Categoria;
public class CategoriaController {
	
	public static void main(String[] args) {
		EntityManagerFactory factory =
				Persistence.createEntityManagerFactory("teste_aula_rc");
		EntityManager manager = factory.createEntityManager();

		Categoria c = new Categoria();
		c.setNome("Lazer");
		manager.getTransaction().begin();
		manager.persist(c);
		manager.getTransaction().commit();
				
		
		Categoria c1 = new Categoria();
		c1.setNome("Música");
		manager.getTransaction().begin();
		manager.persist(c1);
		manager.getTransaction().commit();
		
		manager.close();
		factory.close();
	}
	
}
