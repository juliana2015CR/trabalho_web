package orkut.DAO;

import java.util.List;

import orkut.model.Fotos;

public interface IFotosDAO {
	public void inserir(Fotos fotos);
	public Fotos recuperar(Long fotid);
	public Fotos recuperar(String imagem);
	public List<Fotos> listar();
}
