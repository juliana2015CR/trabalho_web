package orkut.DAO;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import orkut.model.OrkutQuixada;

@Repository
public class OrkutQuixadaDAOHibernate implements IOrkutQuixadaDAO {
	
	@PersistenceContext
	private EntityManager manager;
	
	@Override
	public void inserir(OrkutQuixada orkutquixada) {
		// TODO Auto-generated method stub
		manager.persist(orkutquixada);
	}

	@Override
	public OrkutQuixada recuperar(Long orkid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public OrkutQuixada recuperar(String nome) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<OrkutQuixada> listar() {
		// TODO Auto-generated method stub
		return null;
	}

}
