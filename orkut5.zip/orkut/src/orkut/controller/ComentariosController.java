package orkut.controller;

import java.util.List;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import orkut.DAO.IComentariosDAO;
import orkut.DAO.IFotosDAO;
import orkut.model.Comentarios;
import orkut.model.Forum;
import orkut.model.Fotos;
import orkut.model.Mensagem;


@Controller
@Transactional
public class ComentariosController {
	@Autowired
	@Qualifier(value="comentariosDAOHibernate")
	private IComentariosDAO comentariosDAO;
	
	@Qualifier(value="fotosDAOHibernate")
	private IFotosDAO fotosDAO;
	
	@Autowired
	private ServletContext context;
	
	@RequestMapping("/inserirComentarioFormulario")
	//links
	public String inserirComentarioFormulario(Model model){
		List<Fotos> fotos = fotosDAO.listar();
		model.addAttribute("fotos", fotos);	
		return "comentarios/inserir_comentario_formulario";
	}
	@RequestMapping("/inserirComentario")
	public String inserirComentario(Comentarios comentarios){

		Fotos f = fotosDAO.recuperar(comentarios.getFotId());
		comentarios.setFotos(f);
		
		comentariosDAO.inserir(comentarios);
		return "redirect:listarComentarios";
	}
	@RequestMapping("/listarComentarios")
	public String listarComntarios(Model model, Long id){
		List<Comentarios> comentarios = fotosDAO.listarC(id);
		model.addAttribute("comentarios", comentarios);
		return "comentarios/listar_comentarios";
	}
	
}
