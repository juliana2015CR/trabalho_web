package orkut.DAO;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import orkut.model.Comentarios;
import orkut.model.Mensagem;

@Repository
public class ComentariosDAOHibernate implements IComentariosDAO {

	@PersistenceContext
	private EntityManager manager;
	
	@Override
	public void inserir(Comentarios comentarios) {
		// TODO Auto-generated method stub
		manager.persist(comentarios);
		
		
	}


	@Override
	public Comentarios recuperar(Long comeid) {
		return manager.find(Comentarios.class, comeid);
		}

	@Override
	public Comentarios recuperar(String texto) {
		String hql = "select m from COMENTARIOS as m "
				+ "where m.texto =:var_texto";
		Query query = manager.createQuery(hql, Comentarios.class);
		query.setParameter("var_texto", texto);
		List<Comentarios> comentarios = query.getResultList();

		if (comentarios != null && !comentarios.isEmpty()) {
			return comentarios.get(0);
		}

		return null;
	}

	@Override
	public List<Comentarios> listar() {
		String hql = "select m from COMENTARIOS as m";

		return manager.createQuery(hql, Comentarios.class).getResultList();
	}

}
