package orkut.form;

public class AmizadeCheckBoxForm {
	private Long[] amigos;

	public Long[] getAmigos() {
		return amigos;
	}

	public void setAmigos(Long[] amigos) {
		this.amigos = amigos;
	}

}
