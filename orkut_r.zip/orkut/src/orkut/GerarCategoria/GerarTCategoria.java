package orkut.GerarCategoria;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



public class GerarTCategoria {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory fabrica = Persistence.createEntityManagerFactory("teste_aula_rd");
		fabrica.close();
	}

}