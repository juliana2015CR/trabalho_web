package orkut.DAO;

import java.util.List;

import orkut.model.Forum;

public interface IForumDAO {
	public void inserir(Forum forum);
	public void atualizar(Forum forum);
	public Forum recuperar(Long forId);
	public Forum recuperarMensagem(Long menId);

	public Forum recuperar(String titulo);
	public void apagar(Long forId);
	public List<Forum> listar(Long id);
}
