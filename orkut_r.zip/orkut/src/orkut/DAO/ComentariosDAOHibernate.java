package orkut.DAO;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import orkut.model.Comentarios;

@Repository
public class ComentariosDAOHibernate implements IComentariosDAO {

	@PersistenceContext
	private EntityManager manager;
	
	@Override
	public void inserir(Comentarios comentarios) {
		// TODO Auto-generated method stub
		manager.persist(comentarios);
		
		
	}

	@Override
	public void atualizar(Comentarios comentarios) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Comentarios recuperar(Long comekid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Comentarios recuperar(String texto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Comentarios> listar() {
		// TODO Auto-generated method stub
		return null;
	}

}
