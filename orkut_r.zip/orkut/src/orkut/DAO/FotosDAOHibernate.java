package orkut.DAO;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import orkut.model.Fotos;
@Repository
public class FotosDAOHibernate implements IFotosDAO{
	
	@PersistenceContext
	private EntityManager manager;
	
	@Override
	public void inserir(Fotos fotos) {
		// TODO Auto-generated method stub
		manager.persist(fotos);
	}

	@Override
	public Fotos recuperar(Long fotid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Fotos recuperar(String imagem) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Fotos> listar() {
		// TODO Auto-generated method stub
		return null;
	}

}
