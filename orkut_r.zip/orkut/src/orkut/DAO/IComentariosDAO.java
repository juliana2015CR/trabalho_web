package orkut.DAO;

import java.util.List;

import orkut.model.Comentarios;

public interface IComentariosDAO {

	public void inserir(Comentarios comentarios);
	public void atualizar(Comentarios comentarios);
	public Comentarios recuperar(Long comekid);
	public Comentarios recuperar(String texto);
	public List<Comentarios> listar();
}
