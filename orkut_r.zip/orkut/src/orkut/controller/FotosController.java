package orkut.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;

import orkut.DAO.IFotosDAO;
import orkut.model.Fotos;

@Controller
@Transactional
public class FotosController {
	@Autowired
	@Qualifier(value="fotosDAOHibernate")
	private IFotosDAO fotosDAO;
	
	@RequestMapping("/inserirFotosFormulario")
	//links
	public String inserirFotosFormulario(){
		return "fotos/inserir_fotos_formulario";
	}
	@RequestMapping("/inserirFotos")
	public String inserirFotos(Fotos fotos){
		fotosDAO.inserir(fotos);
		return "fotos/inserir_ok";
	}

}
