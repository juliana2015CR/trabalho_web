package orkut.controller;

import java.util.List;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import orkut.DAO.IAmizadeDAO;
import orkut.model.Amizade;
import orkut.model.Usuario;
import orkut.DAO.UsuarioDAOHibernate;


@Controller
@Transactional
public class AmizadeController {

	@Autowired
	@Qualifier(value="amizadeDAOHibernate")
	private IAmizadeDAO amizadeDAO;
	
	
	@Autowired
	private ServletContext context;
	
	
	@RequestMapping("/listarAmigos")
	public String listarAmigos(Model model){
		List<Amizade> ami = amizadeDAO.listarAmigos();
		for (Amizade u: ami){
			System.out.println(u.getId());
		}
			model.addAttribute("amizades", ami);
			return "amizades/listar_amigos";
	}
	
	
	
	
}
